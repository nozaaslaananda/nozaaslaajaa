
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { motion } from "framer-motion";
import { FaInstagram, FaWhatsapp } from "react-icons/fa";

const Layout = ({ children }) => (
  <div className="bg-gradient-to-b from-purple-900 via-indigo-800 to-pink-700 min-h-screen text-white font-[Poppins]">
    <div className="max-w-5xl mx-auto px-4 py-10 space-y-10">
      {children}
    </div>
  </div>
);

const Home = () => (
  <Layout>
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1 }}
      className="text-center"
    >
      <img
        src="https://i.imgur.com/GYEBqDa.png"
        alt="Noza"
        className="mx-auto w-40 h-40 object-cover rounded-full border-4 border-white shadow-lg"
      />
      <h1 className="text-4xl font-bold mt-4">Noza Asla Ananda</h1>
      <p className="text-xl text-pink-200">Front-End Developer, UI/UX Designer, Web Designer, Creative Technologist</p>
    </motion.div>
  </Layout>
);

const About = () => (
  <Layout>
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      <h2 className="text-3xl font-bold mb-4">Tentang Aku</h2>
      <p className="text-lg">
        🌟 Hai! Aku Noza 👋🏻<br /><br />
        Aku suka banget hal-hal yang berbau kreatif—mulai dari masak-masak di dapur, nulis cerita di Wattpad,
        baca novel sambil ngopi, sampai bikin desain mindmap atau web buat seru-seruan (atau kadang pelampiasan
        ide liar di kepala 😆).<br /><br />
        Buatku, semuanya saling nyambung. Kadang ide nulis datang pas lagi aduk-aduk bumbu, atau inspirasi desain
        muncul dari kalimat di buku yang lagi aku baca. Makanya aku suka banget explore berbagai hal, dan semua itu
        aku tuangin di sini, di portofolio ini.<br /><br />
        Silakan lihat-lihat ya, siapa tahu ada karya yang nyangkut di hati atau bisa jadi awal kolaborasi seru bareng!
      </p>
    </motion.div>
  </Layout>
);

const Projects = () => (
  <Layout>
    <h2 className="text-3xl font-bold mb-4">Projek</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <motion.div
        className="p-4 bg-white text-black rounded-2xl shadow-xl"
        whileHover={{ scale: 1.05 }}
      >
        <h3 className="text-xl font-semibold">🎮 Mini Game Website</h3>
        <p>Website sederhana berisi permainan interaktif untuk hiburan atau edukasi.</p>
      </motion.div>
      <motion.div
        className="p-4 bg-white text-black rounded-2xl shadow-xl"
        whileHover={{ scale: 1.05 }}
      >
        <h3 className="text-xl font-semibold">🌌 Portfolio Ini</h3>
        <p>Website portfolio bergaya galaxy girly dengan animasi penuh dan informasi lengkap tentang Noza.</p>
      </motion.div>
    </div>
  </Layout>
);

const Skills = () => (
  <Layout>
    <h2 className="text-3xl font-bold mb-4">Skill</h2>
    <ul className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
      {["HTML", "CSS", "JAVASCRIPT", "FIGMA"].map(skill => (
        <motion.li
          key={skill}
          className="bg-pink-500 py-2 rounded-xl shadow-lg"
          whileHover={{ scale: 1.1 }}
        >
          {skill}
        </motion.li>
      ))}
    </ul>
  </Layout>
);

const Contact = () => (
  <Layout>
    <h2 className="text-3xl font-bold mb-4">Kontak</h2>
    <div className="space-y-4">
      <p>Email: <a href="mailto:nozaasla08@gmail.com" className="text-pink-200 underline">nozaasla08@gmail.com</a></p>
      <p>Instagram: <a href="https://instagram.com/nozaasla" className="text-pink-200 underline">@nozaasla</a></p>
      <p>WhatsApp: <a href="https://wa.me/6285836793757" className="text-pink-200 underline">+62 858-3679-3757</a></p>
    </div>
  </Layout>
);

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/projects" element={<Projects />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/contact" element={<Contact />} />
    </Routes>
  </Router>
);

export default App;
